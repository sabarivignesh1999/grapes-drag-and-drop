import './App.css';
import WebBuilder from './WebBuilder';

function App() {
  return (
    <div className="App">
         <WebBuilder/>
    </div>
  );
}

export default App;
