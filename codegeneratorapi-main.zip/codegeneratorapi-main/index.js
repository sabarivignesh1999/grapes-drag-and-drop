require('dotenv').config();
require('babel-register');
require('./server');
